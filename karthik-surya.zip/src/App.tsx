/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import About from "./components/About";
import Channels from "./components/Channels";
import Analytics from "./components/Analytics";
import VideosPortal from "./components/VideosPortal";
import Television from "./components/Television";
import Contact from "./components/Contact";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="relative min-h-screen bg-white text-[#1D1D1F] selection:bg-red-500 selection:text-white">
      {/* Structural fixed navigation */}
      <Navbar />

      {/* Main layout contents */}
      <main className="relative">
        {/* HERO - Kinetic Reveal */}
        <Hero />

        {/* ABOUT - Editorial Narrative */}
        <About />

        {/* CHANNELS - Multi-Channel Network */}
        <Channels />

        {/* ANALYTICS - Bento Box Metrics Ticker */}
        <Analytics />

        {/* VIDEOS PORTAL - GSAP horizontal glide scrub */}
        <VideosPortal />

        {/* TELEVISION - Mainstream Broadcast Gigs */}
        <Television />

        {/* CONNECT - Custom expanded focused form */}
        <Contact />
      </main>

      {/* FOOTER */}
      <Footer />
    </div>
  );
}
