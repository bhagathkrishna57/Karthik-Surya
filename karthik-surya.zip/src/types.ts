/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface YouTubeChannel {
  id: string;
  name: string;
  subscribers: string;
  subscribersCount: number; // for animations if needed
  description: string;
  tagline: string;
  youtubeUrl: string;
  accentColor: string;
  logoUrl?: string;
}

export interface MetricCard {
  id: string;
  title: string;
  value: number;
  suffix: string;
  prefix?: string;
  subtitle: string;
  color: string;
}

export interface VideoPlaceholder {
  id: string;
  title: string;
  views: string;
  duration: string;
  timeAgo: string;
  category: string;
  thumbnailUrl?: string;
  videoUrl?: string;
}

export interface PlaylistPlaceholder {
  id: string;
  title: string;
  videoCount: number;
  color: string;
  textContrast: string;
}

export interface MainstreamShow {
  id: string;
  title: string;
  role: string;
  channel: string;
  description: string;
  highlights: string[];
}
