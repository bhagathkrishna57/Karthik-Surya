/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { YouTubeChannel, MetricCard, VideoPlaceholder, PlaylistPlaceholder, MainstreamShow } from "./types";

export const YOUTUBE_CHANNELS: YouTubeChannel[] = [
  {
    id: "ks-vlogs",
    name: "Karthik Surya Vlogs",
    subscribers: "3.28M",
    subscribersCount: 3280000,
    description: "Kerala's most famous lifestyle hub. Hype, daily adventures, deep circles, and authentic vlogs that make every day of life epic.",
    tagline: "Primary Lifestyle Hub",
    youtubeUrl: "https://www.youtube.com/@KarthikSuryavlogs",
    accentColor: "#FF0000",
    logoUrl: "https://yt3.googleusercontent.com/ytc/AIdro_lj3jMNN-uLRsEc2ks2NydNf9GMXFeRPUWbz3Dk-uPhuA8=s160-c-k-c0x00ffffff-no-rj",
  },
  {
    id: "intelerks",
    name: "Intelerks Podcast",
    subscribers: "380K",
    subscribersCount: 380000,
    description: "Collaborative Malayalam podcast featuring deep-dive conversations, culture talks, comedy sessions, and insightful stories.",
    tagline: "Collaborative Podcast & Deep Dives",
    youtubeUrl: "https://www.youtube.com/results?search_query=Intelerks+Podcast",
    accentColor: "#1d1d1f",
    logoUrl: "https://yt3.googleusercontent.com/HR64RdaI3dqCEo51ZudQT-MQzQowCeEFYggmon6o2zbr4Hn552yQPWMufIZueiXFfBVNZHds-m4=s176-c-k-c0x00ffffff-no-rj-mo",
  },
  {
    id: "pepeepoopoo",
    name: "PePeePooPoo",
    subscribers: "116K",
    subscribersCount: 116000,
    description: "Fast-paced laughter, hilarious shorts, roasting, and high-energy situational comedy from Karthik and friends.",
    tagline: "Comedy, Shorts, & Casual Content",
    youtubeUrl: "https://www.youtube.com/@PePeePooPoo",
    accentColor: "#EAB308",
    logoUrl: "https://yt3.googleusercontent.com/uoXe5Sd4yYECfMOg7vyodbV9YW-Ds3RbNcTrXcslaXYg031TvKLxrWXHtZTmJkDj7E5Afs82BA=s176-c-k-c0x00ffffff-no-rj-mo",
  },
  {
    id: "unleashed",
    name: "Karthik Surya Unleashed",
    subscribers: "99.5K",
    subscribersCount: 99500,
    description: "Unfiltered rants, behind-the-scenes streams, real vlog updates, and gaming content straight from the heart.",
    tagline: "Uncut, Raw, & Gaming Content",
    youtubeUrl: "https://www.youtube.com/@KarthikSuryaUnleashed",
    accentColor: "#3B82F6",
    logoUrl: "https://yt3.googleusercontent.com/AicnB2SNnTmLXZmBC1TTYESUBIDdVTh9I-L7bBWrB8ouVctJlFxgfh44mBzNs1VQ6m-xBf1OqN4=s176-c-k-c0x00ffffff-no-rj-mo",
  },
];

export const METRIC_CARDS: MetricCard[] = [
  {
    id: "total-views",
    title: "Total Views",
    value: 1.31,
    suffix: "B+",
    subtitle: "Over 1,319,858,836 Lifetime Views",
    color: "bg-[#F5F5F7]",
  },
  {
    id: "growth-rate",
    title: "Growth Rate",
    value: 15,
    prefix: "+",
    suffix: "%",
    subtitle: "Quarter-over-Quarter Audience Expansion",
    color: "bg-[#00000 Black]", // custom accent color class fallback handled
  },
  {
    id: "monthly-reach",
    title: "Monthly Reach",
    value: 12,
    suffix: "M+",
    subtitle: "Unique Active Viewers Per Month",
    color: "bg-[#F5F5F7]",
  },
  {
    id: "engagement-rate",
    title: "Engagement Rate",
    value: 8.4,
    suffix: "%",
    subtitle: "Industry-Leading Viewer Retention",
    color: "bg-[#F5F5F7]",
  },
];

export const LATEST_VIDEOS: VideoPlaceholder[] = [
  {
    id: "lat-1",
    title: "🏖️Lakshwadeep underwater ഞങ്ങളെ ഞെട്ടിച്ചു 😱",
    views: "174K views",
    duration: "35:49",
    timeAgo: "1 day ago",
    category: "Travel",
    thumbnailUrl: "https://i.ytimg.com/an_webp/PXK6-lhdFY8/mqdefault_6s.webp?du=3000&sqp=CNe2qtEG&rs=AOn4CLCxm4i3aJosL2Q9us4-KOCk-vQO0w",
    videoUrl: "https://www.youtube.com/watch?v=PXK6-lhdFY8"
  },
  {
    id: "lat-2",
    title: "Our First Family Trip Begins✈️",
    views: "336K views",
    duration: "46:50",
    timeAgo: "4 days ago",
    category: "Family",
    thumbnailUrl: "https://i.ytimg.com/an_webp/otUj_lZ18D8/mqdefault_6s.webp?du=3000&sqp=CP_GqtEG&rs=AOn4CLCgRpW0mDVMeSN7AzFfC4FWLpT4KA",
    videoUrl: "https://www.youtube.com/watch?v=otUj_lZ18D8"
  },
  {
    id: "lat-3",
    title: "Surprised by Manju Chechi 😱",
    views: "257K views",
    duration: "25:49",
    timeAgo: "6 days ago",
    category: "Vlogs",
    thumbnailUrl: "https://i.ytimg.com/an_webp/S77-2YNZlc8/mqdefault_6s.webp?du=3000&sqp=CMnDqtEG&rs=AOn4CLDUS2-h4KpfLb1G2j_WupE3IcmO4A",
    videoUrl: "https://www.youtube.com/watch?v=S77-2YNZlc8"
  },
  {
    id: "lat-4",
    title: "Best Entertainer Award on my Birthday 🏆😱",
    views: "165K views",
    duration: "41:04",
    timeAgo: "8 days ago",
    category: "Milestone",
    thumbnailUrl: "https://i.ytimg.com/an_webp/H7O2u5ksinU/mqdefault_6s.webp?du=3000&sqp=CKvMqtEG&rs=AOn4CLCZ-NGfsptH8QZnd8owVrex2T3hdw",
    videoUrl: "https://www.youtube.com/watch?v=H7O2u5ksinU"
  },
  {
    id: "lat-5",
    title: "I got the Biggest Surprises on my പിറന്നാൾ🎁",
    views: "329K views",
    duration: "38:44",
    timeAgo: "10 days ago",
    category: "Birthday",
    thumbnailUrl: "https://i.ytimg.com/an_webp/Q0AACQMQ0Og/mqdefault_6s.webp?du=3000&sqp=CLDOqtEG&rs=AOn4CLCEUZhQiyGY89bOafxQ1Gec5cWazg",
    videoUrl: "https://www.youtube.com/watch?v=Q0AACQMQ0Og"
  },
  {
    id: "lat-6",
    title: "മഞ്ജു ചേച്ചിയെ പിറന്നാളിന് ഞെട്ടിച്ചപ്പോൾ 😱",
    views: "698K views",
    duration: "15:41",
    timeAgo: "4 weeks ago",
    category: "Surprise",
    thumbnailUrl: "https://i.ytimg.com/an_webp/kYAhuS6Jz_Q/mqdefault_6s.webp?du=3000&sqp=CKC4qtEG&rs=AOn4CLBx0CqkzwhXWp-woqErPeKqlzZi_w",
    videoUrl: "https://www.youtube.com/watch?v=kYAhuS6Jz_Q"
  }
];

export const POPULAR_VIDEOS: VideoPlaceholder[] = [
  {
    id: "pop-1",
    title: "1 ലക്ഷം 1 രൂപ കൊടുത്തു iPhone 11 വാങ്ങിയ കഥ",
    views: "7.2M views",
    duration: "18:14",
    timeAgo: "6 years ago",
    category: "Viral",
    thumbnailUrl: "https://i.ytimg.com/an_webp/izSRbqkh8IA/mqdefault_6s.webp?du=3000&sqp=CKDKqtEG&rs=AOn4CLDoC5s69grwMxqthUKcI8KW8lJ_Qg",
    videoUrl: "https://www.youtube.com/watch?v=izSRbqkh8IA"
  },
  {
    id: "pop-2",
    title: "CELEBRITIES vs WORLDS SMELLIEST FOOD🤮(surströmming)",
    views: "4.3M views",
    duration: "21:05",
    timeAgo: "5 years ago",
    category: "Challenge",
    thumbnailUrl: "https://i.ytimg.com/an_webp/i-HqIRx169c/mqdefault_6s.webp?du=3000&sqp=CKW2qtEG&rs=AOn4CLCWIoVLbB6ENtXjT37hgNYCI5rLtA",
    videoUrl: "https://www.youtube.com/watch?v=i-HqIRx169c"
  },
  {
    id: "pop-3",
    title: "മഞ്ജു പിള്ളയുടെ കോടികളുടെ ഫ്ലാറ്റ് ടൂർ 🤑",
    views: "3.4M views",
    duration: "15:40",
    timeAgo: "3 years ago",
    category: "Home Tour",
    thumbnailUrl: "https://i.ytimg.com/an_webp/DnrulnrfhcY/mqdefault_6s.webp?du=3000&sqp=CPzVqtEG&rs=AOn4CLDbe8S7tUglZLqskDv6qhWh33FFyg",
    videoUrl: "https://www.youtube.com/watch?v=DnrulnrfhcY"
  },
  {
    id: "pop-4",
    title: "അങ്ങിനെ ENGAGEMENTഉം കഴിഞ്ഞു 👰🏻😌",
    views: "3.3M views",
    duration: "12:10",
    timeAgo: "5 years ago",
    category: "Celebration",
    thumbnailUrl: "https://i.ytimg.com/an_webp/NbL9qUED7es/mqdefault_6s.webp?du=3000&sqp=CK2wqtEG&rs=AOn4CLDV5fXzDxXmmFTCNzRNQv4Qrn3UWg",
    videoUrl: "https://www.youtube.com/watch?v=NbL9qUED7es"
  },
  {
    id: "pop-5",
    title: "1 LAKH ഒരു DELIVERY BOY ക്ക് TIP കൊടുത്ത കഥ😳",
    views: "3M views",
    duration: "14:50",
    timeAgo: "5 years ago",
    category: "Kindness",
    thumbnailUrl: "https://i.ytimg.com/an_webp/EpLUOqWTtag/mqdefault_6s.webp?du=3000&sqp=CKjYqtEG&rs=AOn4CLBWzPjEeJXrwJ0gWmtMCSmF2MM6pw",
    videoUrl: "https://www.youtube.com/watch?v=EpLUOqWTtag"
  },
  {
    id: "pop-6",
    title: "WORLDS RECORD BIGGEST SNAKE 🐍 & LADDER 🪜 GAME",
    views: "2.7M views",
    duration: "22:30",
    timeAgo: "4 years ago",
    category: "Enterprise",
    thumbnailUrl: "https://i.ytimg.com/an_webp/57W7DcGPiN8/mqdefault_6s.webp?du=3000&sqp=CLO4qtEG&rs=AOn4CLCO66x4IhDabBCBLcMIGtYRuKHbCw",
    videoUrl: "https://www.youtube.com/watch?v=57W7DcGPiN8"
  }
];

export const FEATURED_PLAYLISTS: PlaylistPlaceholder[] = [
  {
    id: "play-1",
    title: "Kerala Life Vlogs",
    videoCount: 150,
    color: "from-[#F5F5F7] to-[#e4e4e7]",
    textContrast: "text-[#1d1d1f]",
  },
  {
    id: "play-2",
    title: "Wanderlust India & Global Travels",
    videoCount: 82,
    color: "from-[#1d1d1f] to-[#27272a]",
    textContrast: "text-white",
  },
  {
    id: "play-3",
    title: "Behind the Scenes & Chaos",
    videoCount: 45,
    color: "from-[#F5F5F7] to-[#e4e4e7]",
    textContrast: "text-[#1d1d1f]",
  },
];

export const MAINSTREAM_SHOWS: MainstreamShow[] = [
  {
    id: "show-1",
    title: "Oru Chiri Iru Chiri Bumper Chiri",
    role: "Hit Comedy Show Host",
    channel: "Mazhavil Manorama",
    description: "Karthik guides a lineup of Kerala's finest comic artists, viral stars, and internet meme creators. With his infectious laughter and quick wit, the show has become a gold standard in regional family entertainment.",
    highlights: ["Highest-rated weekend show in Malayalam television history", "300+ comedy-packed episodes reached", "Created viral social media trends across Kerala"],
  },
  {
    id: "show-2",
    title: "The Next Top Anchor",
    role: "Reality Show Judge",
    channel: "Manoramamax & Television",
    description: "A prestigious talent hunt targeting the next generation of presentation stars in Kerala. Karthik applies his seasoned vlogging mindset, presentation mastery, and entertainment benchmarks to select Kerala's next anchor sensation.",
    highlights: ["Mentored dozens of budding media personalities", "Celebrated for constructive feedback and performance advice", "Direct bridging of digital and mainstream media standards"],
  },
];
