/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ArrowUp, Heart } from "lucide-react";

export default function Footer() {
  const handleScrollToTop = () => {
    window.scrollTo({
      top: 0,
      behavior: "smooth"
    });
  };

  return (
    <footer
      id="main-footer"
      className="bg-[#1D1D1F] text-[#86868B] py-16 md:py-24 px-6 md:px-12 border-t border-neutral-800"
    >
      <div className="max-w-7xl mx-auto flex flex-col justify-between space-y-12 md:space-y-16">
        
        {/* Foot top layout */}
        <div className="flex flex-col md:flex-row md:justify-between items-start md:items-center gap-8 border-b border-neutral-800 pb-12">
          <div className="space-y-3">
            <h3 className="font-display font-extrabold text-[#F5F5F7] text-lg tracking-wider">
              KARTHIK SURYA
            </h3>
            <p className="font-sans text-xs text-neutral-500 max-w-sm">
              Connecting digital content with mainstream television and high-energy storytelling across Thiruvananthapuram and global Malayalam networks.
            </p>
          </div>

          {/* Core anchor triggers */}
          <div className="flex flex-wrap gap-x-8 gap-y-4 text-xs font-semibold">
            <a href="https://www.youtube.com/@KarthikSuryavlogs" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">YOUTUBE</a>
            <a href="https://www.instagram.com/karthiksuryavlogs/?hl=en" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">INSTAGRAM</a>
            <a href="https://www.facebook.com/karthiksuryavlogs/" target="_blank" rel="noopener noreferrer" className="hover:text-white transition-colors">FACEBOOK</a>
          </div>
        </div>

        {/* Foot bottom copyright and actions */}
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-6 text-xs">
          <div className="space-y-1.5">
            <p className="font-sans">
              Copyright © 2026 Karthik Surya Vlogs. All rights reserved.
            </p>
            <p className="text-[11px] text-neutral-400 font-sans flex flex-col gap-1 sm:gap-1.5">
              <span>
                Created by <strong className="text-[#F5F5F7] font-medium">Bhagath Krishna.M</strong>
              </span>
              <span className="flex items-center gap-1.5">
                <span className="text-red-500">❤</span>
                <a
                  href="https://www.instagram.com/bhagath.wav/?hl=da"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-red-500 hover:text-red-400 hover:underline transition-colors font-medium inline-flex items-center gap-1"
                >
                  instagram
                </a>
              </span>
            </p>
            <p className="text-[10px] text-neutral-600 font-mono">
              Built with premium structural proportions & elite motion graphics.
            </p>
          </div>

          <button
            id="back-to-top"
            onClick={handleScrollToTop}
            className="group inline-flex items-center gap-2 text-neutral-400 hover:text-white cursor-pointer transition-colors font-mono uppercase text-[10px] tracking-widest bg-neutral-800 px-4 py-2.5 rounded-full border border-neutral-700/50"
          >
            scroll to top
            <ArrowUp size={11} className="group-hover:-translate-y-0.5 duration-200 text-red-500" />
          </button>
        </div>
      </div>
    </footer>
  );
}
