/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Instagram, Facebook, ArrowUpRight, ShieldCheck, MapPin } from "lucide-react";

gsap.registerPlugin(ScrollTrigger);

export default function About() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const textRef = useRef<HTMLParagraphElement>(null);
  const cardGroupRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Elegant scroll trigger fade for the main editorial text
      gsap.fromTo(
        textRef.current,
        { opacity: 0, y: 40 },
        {
          opacity: 1,
          y: 0,
          duration: 1.2,
          ease: "power3.out",
          scrollTrigger: {
            trigger: textRef.current,
            start: "top 80%",
            toggleActions: "play none none none"
          }
        }
      );

      // Stagger social connect items loading
      if (cardGroupRef.current) {
        gsap.fromTo(
          cardGroupRef.current.children,
          { opacity: 0, y: 30 },
          {
            opacity: 1,
            y: 0,
            duration: 1,
            stagger: 0.15,
            ease: "power3.out",
            scrollTrigger: {
              trigger: cardGroupRef.current,
              start: "top 85%",
              toggleActions: "play none none none"
            }
          }
        );
      }
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={sectionRef}
      id="about"
      className="relative bg-[#F5F5F7]/30 py-24 md:py-36 px-6 md:px-12 border-t border-b border-gray-100"
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20">
          {/* Left Column: Context Tagging */}
          <div className="lg:col-span-4 space-y-4">
            <span className="font-mono text-xs font-semibold uppercase tracking-widest text-gray-400 block">
              EDITORIAL NARRATIVE
            </span>
            <h2 className="font-display font-bold text-3xl md:text-4xl text-[#1D1D1F] tracking-tight">
              Bridging digital and mainstream media.
            </h2>
            <div className="flex flex-col space-y-3 pt-3 text-sm text-gray-500 font-sans">
              <div className="flex items-center gap-2">
                <MapPin size={16} className="text-red-500" />
                <span>Thiruvananthapuram, Kerala, India</span>
              </div>
              <div className="flex items-center gap-2">
                <ShieldCheck size={16} className="text-emerald-500" />
                <span>Verified Creator Ecosystem</span>
              </div>
            </div>
          </div>

          {/* Right Column: Editorial Bio Paragraph & Responsive Premium Cards */}
          <div className="lg:col-span-8 flex flex-col justify-between space-y-12">
            <p
              ref={textRef}
              id="editorial-narrative-paragraph"
              className="font-sans text-xl md:text-2xl leading-relaxed text-gray-700 font-normal tracking-wide [word-spacing:0.04em]"
            >
              I am a <span className="text-[#1D1D1F] font-bold">digital creator and vlogger</span> from Kerala, dedicated to bringing high-energy entertainment, raw travel experiences, and relatable lifestyle content to millions of viewers. Known for my signature high-spirited intros and unfiltered storytelling, I turn everyday moments into shared experiences with my digital family.
            </p>

            {/* Structured Details Deck */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Based In Card */}
              <div className="bg-white border border-gray-100 hover:border-red-100 p-6 rounded-3xl transition-all duration-300 shadow-2xs hover:shadow-sm">
                <div className="font-mono text-[10px] text-red-500 font-bold uppercase tracking-wider mb-2">
                  📍 Based In
                </div>
                <p className="font-display font-extrabold text-[#1D1D1F] text-base leading-snug">
                  Thiruvananthapuram / Kozhikode, Kerala
                </p>
              </div>

              {/* Niche Card */}
              <div className="bg-white border border-gray-100 hover:border-red-100 p-6 rounded-3xl transition-all duration-300 shadow-2xs hover:shadow-sm">
                <div className="font-mono text-[10px] text-red-500 font-bold uppercase tracking-wider mb-2">
                  ⚡ Niche Focus
                </div>
                <p className="font-sans text-sm font-semibold text-gray-700 leading-relaxed">
                  Lifestyle Vlogging, Travel, Automobile Reviews, Tech & Unboxing, Celebrity Collabs
                </p>
              </div>

              {/* Core Philosophy Card */}
              <div className="bg-white border border-gray-100 hover:border-red-100 p-6 rounded-3xl transition-all duration-300 shadow-2xs hover:shadow-sm">
                <div className="font-mono text-[10px] text-red-500 font-bold uppercase tracking-wider mb-2">
                  💬 Core Philosophy
                </div>
                <p className="font-display font-bold italic text-[#1D1D1F] text-sm leading-relaxed">
                  "Keeping it real, raw, and entertaining."
                </p>
              </div>
            </div>

            {/* Creator's Authentic Manifesto Block */}
            <div className="bg-[#1D1D1F] text-white p-7 md:p-8 rounded-[32px] border border-neutral-800 shadow-md relative overflow-hidden group">
              <span className="font-mono text-[9px] text-red-500 font-bold tracking-widest uppercase block mb-3 animate-pulse">
                ★ AUTHENTIC CREATOR NARRATIVE & GOAL
              </span>
              <p className="font-display font-medium text-lg md:text-xl leading-relaxed mb-5 text-neutral-100 italic">
                "Helloooooooooo world. I will Die one day and when that time comes, I absolutely DO NOT want to leave any regrets. Now about me, I am a hyperactive entrepreneur who loves passionate people. It's all about hustling with me. I want to make every day of my life epic and in the process make others happy too."
              </p>
              <div className="flex flex-wrap gap-4 items-center justify-between border-t border-neutral-800 pt-4 font-mono text-xs text-neutral-400">
                <span className="font-sans">
                  The Golden Rule: <strong className="text-red-500 font-mono tracking-wider ml-1">GIVE R TO TAKE R</strong>
                </span>
                <span className="text-[10px] tracking-wider uppercase text-neutral-500">
                  #daretodream • Rock Out
                </span>
              </div>
            </div>

            {/* Direct Connect Buttons Grid */}
            <div className="space-y-4">
              <p className="font-mono text-xs font-semibold text-gray-400 uppercase tracking-widest">
                verified social connections
              </p>

              <div
                ref={cardGroupRef}
                className="grid grid-cols-1 sm:grid-cols-2 gap-4"
              >
                {/* Instagram button */}
                <a
                  href="https://www.instagram.com/karthiksuryavlogs/?hl=en"
                  target="_blank"
                  rel="noopener noreferrer"
                  id="about-link-instagram"
                  className="group relative flex items-center justify-between p-5 bg-white border border-gray-100 rounded-3xl hover:border-pink-200 hover:shadow-xs transition-all duration-300"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-pink-50 flex items-center justify-center text-pink-600 group-hover:scale-105 transition-transform duration-300">
                      <Instagram size={24} />
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-[#1D1D1F] text-sm group-hover:text-pink-600 transition-colors">
                        @karthiksuryavlogs
                      </h4>
                      <p className="font-sans text-xs text-gray-400">
                        1.2M+ Active Followers
                      </p>
                    </div>
                  </div>
                  <ArrowUpRight size={18} className="text-gray-300 group-hover:text-pink-600 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                </a>

                {/* Facebook button */}
                <a
                  href="https://www.facebook.com/karthiksuryavlogs/"
                  target="_blank"
                  rel="noopener noreferrer"
                  id="about-link-facebook"
                  className="group relative flex items-center justify-between p-5 bg-white border border-gray-100 rounded-3xl hover:border-blue-200 hover:shadow-xs transition-all duration-300"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 rounded-2xl bg-blue-50 flex items-center justify-center text-blue-600 group-hover:scale-105 transition-transform duration-300">
                      <Facebook size={24} />
                    </div>
                    <div>
                      <h4 className="font-display font-bold text-[#1D1D1F] text-sm group-hover:text-blue-600 transition-colors">
                        Karthik Surya Vlogs
                      </h4>
                      <p className="font-sans text-xs text-gray-400">
                        Premium Page Verification
                      </p>
                    </div>
                  </div>
                  <ArrowUpRight size={18} className="text-gray-300 group-hover:text-blue-600 group-hover:translate-x-0.5 group-hover:-translate-y-0.5 transition-all" />
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
