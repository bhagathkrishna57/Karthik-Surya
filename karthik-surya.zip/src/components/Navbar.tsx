/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Menu, X, ArrowUpRight } from "lucide-react";

export default function Navbar() {
  const [activeSection, setActiveSection] = useState("home");
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);

  const navigationItems = [
    { label: "Home", id: "home" },
    { label: "About", id: "about" },
    { label: "Channels", id: "channels" },
    { label: "Analytics", id: "analytics" },
    { label: "Videos", id: "videos" },
    { label: "Television", id: "television" },
    { label: "Connect", id: "connect" },
  ];

  useEffect(() => {
    const handleScroll = () => {
      setScrolled(window.scrollY > 50);

      // Simple intersection tracker
      const scrollPosition = window.scrollY + 120;
      for (const item of navigationItems) {
        const element = document.getElementById(item.id);
        if (element) {
          const top = element.offsetTop;
          const height = element.offsetHeight;
          if (scrollPosition >= top && scrollPosition < top + height) {
            setActiveSection(item.id);
          }
        }
      }
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const scrollToSection = (id: string) => {
    setMobileMenuOpen(false);
    const element = document.getElementById(id);
    if (element) {
      const offset = 80; // height of navbar
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <nav
      id="main-navbar"
      className={`fixed top-0 left-0 w-full z-50 transition-all duration-300 ${
        scrolled
          ? "py-4 border-b border-gray-100/60 shadow-xs"
          : "py-6"
      }`}
      style={{
        backdropFilter: "blur(20px)",
        WebkitBackdropFilter: "blur(20px)",
        background: scrolled ? "rgba(255, 255, 255, 0.85)" : "rgba(255, 255, 255, 0.6)",
      }}
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 flex justify-between items-center">
        {/* Logo / Title */}
        <button
          id="navbar-brand"
          onClick={() => scrollToSection("home")}
          className="font-display font-bold text-xl tracking-tight text-[#1D1D1F] transition-all hover:opacity-85 cursor-pointer flex items-center gap-2.5"
        >
          <img
            src="https://yt3.googleusercontent.com/ytc/AIdro_lj3jMNN-uLRsEc2ks2NydNf9GMXFeRPUWbz3Dk-uPhuA8=s160-c-k-c0x00ffffff-no-rj"
            alt="Karthik Surya"
            referrerPolicy="no-referrer"
            className="w-8 h-8 rounded-full border border-gray-200 object-cover shadow-2xs"
          />
          <span>KARTHIK SURYA</span>
          <div className="w-1.5 h-1.5 rounded-full bg-red-600 animate-pulse" />
        </button>

        {/* Desktop Links */}
        <div className="hidden md:flex items-center space-x-8">
          {navigationItems.map((item) => (
            <button
              key={item.id}
              id={`nav-link-${item.id}`}
              onClick={() => scrollToSection(item.id)}
              className={`font-sans text-xs font-semibold tracking-wider uppercase transition-colors duration-200 cursor-pointer ${
                activeSection === item.id
                  ? "text-[#1D1D1F]"
                  : "text-gray-400 hover:text-[#1D1D1F]"
              }`}
            >
              {item.label}
            </button>
          ))}
          <button
            id="nav-cta-button"
            onClick={() => scrollToSection("connect")}
            className="flex items-center gap-1.5 text-xs font-semibold uppercase tracking-wider bg-[#1D1D1F] text-white px-4 py-2.5 rounded-full hover:bg-neutral-800 transition-all"
          >
            Connect
            <ArrowUpRight size={13} />
          </button>
        </div>

        {/* Mobile Hamburger Toggle */}
        <button
          id="mobile-menu-toggle"
          onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
          className="md:hidden text-[#1D1D1F] p-1.5 focus:outline-none cursor-pointer"
          aria-label="Toggle Menu"
        >
          {mobileMenuOpen ? <X size={20} /> : <Menu size={20} />}
        </button>
      </div>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div
          id="mobile-drawer"
          className="md:hidden absolute top-full left-0 w-full bg-white border-b border-gray-100 flex flex-col px-6 py-6 space-y-4 animate-fade-in z-40 shadow-lg"
          style={{
            backdropFilter: "blur(20px)",
            WebkitBackdropFilter: "blur(20px)",
            background: "rgba(255, 255, 255, 0.98)",
          }}
        >
          {navigationItems.map((item) => (
            <button
              key={item.id}
              id={`mob-nav-link-${item.id}`}
              onClick={() => scrollToSection(item.id)}
              className={`text-left font-display text-lg font-medium py-1.5 transition-colors ${
                activeSection === item.id
                  ? "text-[#1D1D1F] font-bold"
                  : "text-gray-500"
              }`}
            >
              {item.label}
            </button>
          ))}
          <button
            id="mob-nav-cta"
            onClick={() => scrollToSection("connect")}
            className="flex items-center justify-center gap-2 text-sm font-semibold uppercase tracking-wider bg-[#1D1D1F] text-white py-3 rounded-xl hover:bg-neutral-800 transition-all w-full mt-2"
          >
            Connect
            <ArrowUpRight size={14} />
          </button>
        </div>
      )}
    </nav>
  );
}
