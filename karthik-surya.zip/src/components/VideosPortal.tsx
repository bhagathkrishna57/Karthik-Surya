/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Play, Flame, FolderHeart, Eye, Clock, ListMusic, Trophy } from "lucide-react";
import { LATEST_VIDEOS, POPULAR_VIDEOS, FEATURED_PLAYLISTS } from "../data";
import { VideoPlaceholder } from "../types";

gsap.registerPlugin(ScrollTrigger);

interface VideoCardProps {
  video: VideoPlaceholder;
}

const VideoCard: React.FC<VideoCardProps> = ({ video }) => {
  const [isHovered, setIsHovered] = useState(false);

  // Extract YouTube ID to load static thumbnail by default, and swap to animated webp on hover
  const getYoutubeVideoId = (url: string | undefined) => {
    if (!url) return "";
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : "";
  };

  const videoId = getYoutubeVideoId(video.videoUrl);
  const staticThumbnailUrl = videoId 
    ? `https://img.youtube.com/vi/${videoId}/hqdefault.jpg`
    : "";

  return (
    <div
      id={`video-${video.id}`}
      className="w-[300px] sm:w-[480px] shrink-0 font-sans"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Clickable Youtube Frame */}
      <a
        href={video.videoUrl || "https://www.youtube.com/@KarthikSuryavlogs"}
        target="_blank"
        rel="noopener noreferrer"
        className="group relative block aspect-[16/9] w-full bg-[#1D1D1F] rounded-[24px] overflow-hidden border border-gray-100/60 shadow-2xs flex flex-col justify-between p-6 transition-all duration-300 hover:border-red-500/30 hover:shadow-lg cursor-pointer"
      >
        {/* Background Visual Image from Youtube */}
        {video.thumbnailUrl ? (
          <>
            <img
              src={isHovered ? video.thumbnailUrl : staticThumbnailUrl}
              alt={video.title}
              referrerPolicy="no-referrer"
              className={`absolute inset-0 w-full h-full object-cover transition-all duration-700 ease-out ${
                isHovered 
                  ? "opacity-70 scale-105" 
                  : "opacity-85 scale-100"
              }`}
            />
            <div className="absolute inset-0 bg-linear-to-t from-black/90 via-black/35 to-black/30 group-hover:from-black/95 transition-colors" />
          </>
        ) : (
          <>
            <div className="absolute inset-0 bg-linear-to-b from-neutral-800 to-neutral-900 group-hover:scale-105 transition-transform duration-500" />
            <div className="absolute inset-0 opacity-15 mix-blend-overlay bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px]" />
          </>
        )}
        
        {/* Top row meta indicators */}
        <div className="flex justify-between items-start z-10">
          <span className="font-mono text-[9px] uppercase font-bold text-white bg-black/60 backdrop-blur-xs px-2.5 py-1 rounded-md border border-white/5 tracking-wider">
            {video.category}
          </span>
          <span className="font-mono text-[9px] font-bold text-white bg-red-600 px-2 py-0.5 rounded-sm shadow-xs">
            {video.duration}
          </span>
        </div>

        {/* Central Red Premium Play trigger overlay */}
        <div className="w-14 h-14 rounded-full bg-white text-[#1D1D1F] flex items-center justify-center self-center shadow-lg transform scale-90 group-hover:scale-100 group-hover:bg-red-600 group-hover:text-white transition-all duration-300 z-10">
          <Play size={20} className="fill-current ml-1" />
        </div>

        {/* Live statistics footer overlay */}
        <div className="flex justify-between items-center bg-white/10 backdrop-blur-md p-3.5 rounded-2xl border border-white/10 z-10">
          <div className="flex items-center gap-2 text-xs text-neutral-200 font-medium font-sans">
            <Eye size={13} className="text-red-400" />
            <span>{video.views}</span>
          </div>
          <div className="flex items-center gap-1.5 text-xs text-neutral-200 font-medium font-sans">
            <Clock size={13} className="text-red-400" />
            <span>{video.timeAgo}</span>
          </div>
        </div>
      </a>

      {/* Video Title Meta text */}
      <a
        href={video.videoUrl || "https://www.youtube.com/@KarthikSuryavlogs"}
        target="_blank"
        rel="noopener noreferrer"
        className="block font-display font-semibold text-base md:text-lg text-[#1D1D1F] hover:text-red-600 transition-colors mt-4 line-clamp-2 px-1 cursor-pointer"
      >
        {video.title}
      </a>
    </div>
  );
}

export default function VideosPortal() {
  const containerRef = useRef<HTMLDivElement>(null);
  const rowLatestRef = useRef<HTMLDivElement>(null);
  const rowPopularRef = useRef<HTMLDivElement>(null);
  const rowPlaylistsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // General Header Fade
      gsap.fromTo(
        "#videos-hdr > *",
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: "#videos-hdr",
            start: "top 80%",
            toggleActions: "play none none none"
          }
        }
      );

      // Latest Videos Track - glide left as user scrolls down
      gsap.fromTo(
        rowLatestRef.current,
        { x: "4vw" },
        {
          x: "-14vw",
          ease: "none",
          scrollTrigger: {
            trigger: containerRef.current,
            start: "top bottom",
            end: "bottom top",
            scrub: 1.2,
          }
        }
      );

      // Popular Videos Track - glide right as user scrolls down
      gsap.fromTo(
        rowPopularRef.current,
        { x: "-15vw" },
        {
          x: "3vw",
          ease: "none",
          scrollTrigger: {
            trigger: containerRef.current,
            start: "top bottom",
            end: "bottom top",
            scrub: 1.2,
          }
        }
      );

      // Playlists Track - glide left as user scrolls down
      gsap.fromTo(
        rowPlaylistsRef.current,
        { x: "5vw" },
        {
          x: "-8vw",
          ease: "none",
          scrollTrigger: {
            trigger: containerRef.current,
            start: "top bottom",
            end: "bottom top",
            scrub: 1.2,
          }
        }
      );
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={containerRef}
      id="videos"
      className="bg-white py-24 md:py-36 overflow-hidden border-b border-gray-100"
    >
      <div className="max-w-7xl mx-auto px-6 md:px-12 mb-16 md:mb-20">
        {/* Header */}
        <div id="videos-hdr" className="space-y-4 text-left max-w-2xl">
          <span className="font-mono text-xs font-semibold uppercase tracking-widest text-red-600">
            CINEMATIC ARCHIVES
          </span>
          <h2 className="font-display font-bold text-4xl md:text-5xl text-[#1D1D1F] tracking-tight">
            Featured Content
          </h2>
          <p className="font-sans text-lg text-gray-500">
            Latest high-octane YouTube releases and curated playlists showcasing travel diaries, television insights, and off-beat Kerala activities.
          </p>
        </div>
      </div>

      {/* Horizontal Glide Tracks */}
      <div className="space-y-16 w-full">
        {/* ROW 1: Latest Videos (Glide Left) */}
        <div className="w-full relative">
          <div className="px-6 md:px-12 mb-3">
            <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase font-bold tracking-widest text-[#1D1D1F] px-4 py-1.5 bg-neutral-100 rounded-full">
              <Flame size={12} className="text-red-500 animate-pulse" />
              Latest Uploads (Row scrub ◄)
            </span>
          </div>

          <div className="overflow-visible flex">
            <div
              ref={rowLatestRef}
              className="flex gap-6 md:gap-8 will-change-transform pr-12"
              style={{ width: "fit-content" }}
            >
              {LATEST_VIDEOS.map((video) => (
                <VideoCard key={video.id} video={video} />
              ))}
            </div>
          </div>
        </div>

        {/* ROW 2: Most Popular (Glide Right) */}
        <div className="w-full relative">
          <div className="px-6 md:px-12 mb-3">
            <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase font-bold tracking-widest text-[#1D1D1F] px-4 py-1.5 bg-neutral-100 rounded-full">
              <Trophy size={11} className="text-yellow-600" />
              All-Time Hits (Row scrub ►)
            </span>
          </div>

          <div className="overflow-visible flex">
            <div
              ref={rowPopularRef}
              className="flex gap-6 md:gap-8 will-change-transform pr-12"
              style={{ width: "fit-content" }}
            >
              {POPULAR_VIDEOS.map((video) => (
                <VideoCard key={video.id} video={video} />
              ))}
            </div>
          </div>
        </div>

        {/* DEDICATED CONTENT PORTFOLIOS DECK */}
        <div id="content-portfolios-section" className="px-6 md:px-12 pt-16 border-t border-gray-100">
          <div className="mb-10 text-left">
            <span className="inline-flex items-center gap-1.5 font-mono text-[10px] uppercase font-bold tracking-widest text-red-600 px-4 py-1.5 bg-red-50 rounded-full mb-3">
              <FolderHeart size={12} className="animate-pulse" />
              🎬 Content Portfolios & Playlists
            </span>
            <h3 className="font-display font-bold text-3xl md:text-4xl text-[#1D1D1F] tracking-tight">
              Curated Production Pillars
            </h3>
            <p className="font-sans text-sm text-gray-500 max-w-xl mt-1">
              Deep dive into my specialized entertainment segments. Each pillar has distinct narrative styles and audience engagement hooks.
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {/* Portfolio 1: Travel */}
            <div className="group relative bg-[#F5F5F7]/30 border border-gray-100 hover:border-red-100/60 p-8 rounded-[32px] transition-all duration-300 flex flex-col justify-between hover:shadow-lg">
              <div>
                <div className="flex justify-between items-start mb-6">
                  <span className="font-mono text-[10px] uppercase font-bold tracking-widest text-red-600 px-3 py-1 bg-red-50 rounded-lg">
                    Segment 01
                  </span>
                  <span className="font-mono text-[9px] text-gray-400 font-semibold uppercase">
                    Travel & Adventure
                  </span>
                </div>
                <h4 className="font-display font-extrabold text-2xl text-[#1D1D1F] mb-3 group-hover:text-red-600 transition-colors">
                  Travel & Adventure Vlogs
                </h4>
                <p className="font-sans text-sm text-gray-600 leading-relaxed mb-6">
                  Exploring landscapes, tasting local cuisines, and experiencing different cultures unfiltered.
                </p>

                {/* Highlights List */}
                <div className="space-y-3 mb-8">
                  <p className="font-mono text-[9px] font-bold text-gray-400 uppercase tracking-widest">
                    Highlights
                  </p>
                  <ul className="space-y-2 text-xs text-gray-700 font-sans">
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 font-bold font-mono">✓</span>
                      <span>Solo backpacking trips across key terrains</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 font-bold font-mono">✓</span>
                      <span>Luxury stays & hospitality reviews</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-red-500 font-bold font-mono">✓</span>
                      <span>Uncovering hidden gems across India & international destinations</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Style signature info */}
              <div className="border-t border-gray-100/85 pt-4 bg-transparent font-sans text-xs text-gray-500">
                <span className="font-mono text-[9px] font-bold block text-gray-400 uppercase tracking-wider mb-1">
                  Production Style
                </span>
                <p className="font-medium italic text-gray-700">
                  Cinematic drone shots paired with raw, on-the-ground storytelling.
                </p>
              </div>
            </div>

            {/* Portfolio 2: Challenge */}
            <div className="group relative bg-[#F5F5F7]/30 border border-gray-100 hover:border-red-100/60 p-8 rounded-[32px] transition-all duration-300 flex flex-col justify-between hover:shadow-lg">
              <div>
                <div className="flex justify-between items-start mb-6">
                  <span className="font-mono text-[10px] uppercase font-bold tracking-widest text-[#1D1D1F] px-3 py-1 bg-neutral-100 rounded-lg">
                    Segment 02
                  </span>
                  <span className="font-mono text-[9px] text-gray-400 font-semibold uppercase">
                    Lifestyle & Fun
                  </span>
                </div>
                <h4 className="font-display font-extrabold text-2xl text-[#1D1D1F] mb-3 group-hover:text-red-600 transition-colors">
                  Challenge & Lifestyle Vlogs
                </h4>
                <p className="font-sans text-sm text-gray-600 leading-relaxed mb-6">
                  High-energy, fun-filled videos featuring friends, family, and prominent internet personalities.
                </p>

                {/* Highlights List */}
                <div className="space-y-3 mb-8">
                  <p className="font-mono text-[9px] font-bold text-gray-400 uppercase tracking-widest">
                    Highlights
                  </p>
                  <ul className="space-y-2 text-xs text-gray-700 font-sans">
                    <li className="flex items-start gap-2">
                      <span className="text-[#1D1D1F] font-bold font-mono">✓</span>
                      <span>Fan-favourite "Truth or Dare" series</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#1D1D1F] font-bold font-mono">✓</span>
                      <span>Extreme, creative 24-hour challenges</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#1D1D1F] font-bold font-mono">✓</span>
                      <span>Massive, viral giveaway videos that reward subscribers</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Style signature info */}
              <div className="border-t border-gray-100/85 pt-4 bg-transparent font-sans text-xs text-gray-500">
                <span className="font-mono text-[9px] font-bold block text-gray-400 uppercase tracking-wider mb-1">
                  Production Style
                </span>
                <p className="font-medium italic text-gray-700">
                  Fast-paced, humor-driven editing that keeps viewers hooked from start to finish.
                </p>
              </div>
            </div>

            {/* Portfolio 3: Automobile & Tech */}
            <div className="group relative bg-[#F5F5F7]/30 border border-gray-100 hover:border-red-100/60 p-8 rounded-[32px] transition-all duration-300 flex flex-col justify-between hover:shadow-lg">
              <div>
                <div className="flex justify-between items-start mb-6">
                  <span className="font-mono text-[10px] uppercase font-bold tracking-widest text-[#1D1D1F] px-3 py-1 bg-neutral-100 rounded-lg">
                    Segment 03
                  </span>
                  <span className="font-mono text-[9px] text-gray-400 font-semibold uppercase">
                    Automobile & Tech
                  </span>
                </div>
                <h4 className="font-display font-extrabold text-2xl text-[#1D1D1F] mb-3 group-hover:text-red-600 transition-colors">
                  Automobile & Tech Highlights
                </h4>
                <p className="font-sans text-sm text-gray-600 leading-relaxed mb-6">
                  Unboxing the latest tech gear and giving honest, enthusiastic reviews of cars and bikes.
                </p>

                {/* Highlights List */}
                <div className="space-y-3 mb-8">
                  <p className="font-mono text-[9px] font-bold text-gray-400 uppercase tracking-widest">
                    Highlights
                  </p>
                  <ul className="space-y-2 text-xs text-gray-700 font-sans">
                    <li className="flex items-start gap-2">
                      <span className="text-[#1D1D1F] font-bold font-mono">✓</span>
                      <span>Custom vehicle modifications & cosmetic gear reviews</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#1D1D1F] font-bold font-mono">✓</span>
                      <span>Behind-the-scenes garage tours & vehicle showcases</span>
                    </li>
                    <li className="flex items-start gap-2">
                      <span className="text-[#1D1D1F] font-bold font-mono">✓</span>
                      <span>Long-distance road-trip test drives & reliability tests</span>
                    </li>
                  </ul>
                </div>
              </div>

              {/* Style signature info */}
              <div className="border-t border-gray-100/85 pt-4 bg-transparent font-sans text-xs text-gray-500">
                <span className="font-mono text-[9px] font-bold block text-gray-400 uppercase tracking-wider mb-1">
                  Production Style
                </span>
                <p className="font-medium italic text-gray-700">
                  Fast-paced, high-spirited, extremely honest and enthusiastic review structures.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
