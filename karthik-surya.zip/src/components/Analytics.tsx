/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef, useState } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { BarChart3, TrendingUp, Users, Activity } from "lucide-react";
import { METRIC_CARDS } from "../data";

gsap.registerPlugin(ScrollTrigger);

// Custom CountUp Component using GSAP
function AnimatedNumber({ value, prefix = "", suffix = "", delay = 0 }: { value: number; prefix?: string; suffix?: string; delay?: number }) {
  const [displayValue, setDisplayValue] = useState(0);
  const numberRef = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const target = { val: 0 };
    const isDecimal = value % 1 !== 0;

    const anim = gsap.to(target, {
      val: value,
      duration: 1.8,
      delay: delay,
      ease: "power2.out",
      scrollTrigger: {
        trigger: numberRef.current,
        start: "top 85%",
        toggleActions: "play none none none",
      },
      onUpdate: () => {
        setDisplayValue(isDecimal ? parseFloat(target.val.toFixed(1)) : Math.floor(target.val));
      },
    });

    return () => {
      anim.kill();
    };
  }, [value, delay]);

  return (
    <span ref={numberRef} className="tabular-nums">
      {prefix}
      {displayValue}
      {suffix}
    </span>
  );
}

export default function Analytics() {
  const containerRef = useRef<HTMLDivElement>(null);
  const gridRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Fade in header elements
      gsap.fromTo(
        "#analytics-header > *",
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: "#analytics-header",
            start: "top 80%",
            toggleActions: "play none none none"
          }
        }
      );

      // Stagger elements inside the bento grid itself
      if (gridRef.current) {
        gsap.fromTo(
          gridRef.current.children,
          { opacity: 0, y: 40, scale: 0.98 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 1.2,
            stagger: 0.15,
            ease: "power4.out",
            scrollTrigger: {
              trigger: gridRef.current,
              start: "top 80%",
              toggleActions: "play none none none"
            }
          }
        );
      }
    }, containerRef);

    return () => ctx.revert();
  }, []);

  const getMetricIcon = (id: string, darkTheme: boolean) => {
    const className = darkTheme ? "text-red-500" : "text-[#1D1D1F]";
    switch (id) {
      case "total-views":
        return <BarChart3 size={24} className={className} />;
      case "growth-rate":
        return <TrendingUp size={24} className="text-red-500" />;
      case "monthly-reach":
        return <Users size={24} className={className} />;
      case "engagement-rate":
        return <Activity size={24} className={className} />;
      default:
        return <TrendingUp size={24} className={className} />;
    }
  };

  return (
    <section
      ref={containerRef}
      id="analytics"
      className="bg-[#F5F5F7]/35 py-24 md:py-36 px-6 md:px-12 border-t border-b border-gray-100"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div id="analytics-header" className="space-y-4 mb-16 md:mb-24 text-left max-w-2xl">
          <span className="font-mono text-xs font-semibold uppercase tracking-widest text-[#1D1D1F]">
            AUDIENCE INSIGHTS & RETENTION
          </span>
          <h2 className="font-display font-bold text-4xl md:text-5xl text-[#1D1D1F] tracking-tight">
            Key Channel Performance
          </h2>
          <p className="font-sans text-lg text-gray-500">
            Real metric performance indicating audience loyalty, engagement percentages, and quarterly scaling milestones.
          </p>
        </div>

        {/* Bento Box Grid - Proportional asymmetrical layouts */}
        <div
          ref={gridRef}
          id="analytics-bento-grid"
          className="grid grid-cols-1 md:grid-cols-3 gap-6"
        >
          {METRIC_CARDS.map((card) => {
            const isDark = card.id === "growth-rate"; // Keep growth rate card dark for premium contrast
            const colSpan = card.id === "total-views" || card.id === "engagement-rate" 
              ? "md:col-span-2" 
              : "md:col-span-1";

            return (
              <div
                key={card.id}
                id={`analytics-bento-${card.id}`}
                className={`${colSpan} group relative p-8 md:p-10 rounded-[32px] overflow-hidden flex flex-col justify-between min-h-[240px] md:min-h-[290px] transition-all duration-300 ${
                  isDark 
                    ? "bg-[#1D1D1F] text-white border border-neutral-800" 
                    : "bg-white text-[#1D1D1F] border border-gray-100/80 hover:border-gray-200"
                } shadow-xs hover:shadow-lg`}
              >
                {/* Visual Accent Layer */}
                {!isDark && (
                  <div className="absolute inset-0 bg-linear-to-b from-[#FAFAFC]/40 to-[#F5F5F7]/40 -z-10 group-hover:scale-105 transition-transform duration-500" />
                )}
                {isDark && (
                  <div className="absolute inset-0 bg-linear-to-b from-neutral-800/20 to-neutral-900/30 -z-10 group-hover:scale-105 transition-transform duration-500" />
                )}

                {/* Card Top: Icon & Indicator */}
                <div className="flex justify-between items-start">
                  <div className={`p-3 rounded-2xl ${isDark ? "bg-white/10" : "bg-[#F5F5F7]"}`}>
                    {getMetricIcon(card.id, isDark)}
                  </div>
                  <span className={`font-mono text-[9px] uppercase font-bold tracking-widest ${isDark ? "text-neutral-500" : "text-gray-400"}`}>
                    LIVE AUDIT
                  </span>
                </div>

                {/* Card Center: Animated Metric */}
                <div className="my-6">
                  <div className="font-display font-extrabold text-[#1D1D1F] text-5xl md:text-6xl tracking-tight leading-none mb-2">
                    <span className={isDark ? "text-white" : "text-[#1D1D1F]"}>
                      <AnimatedNumber
                        value={card.value}
                        prefix={card.prefix}
                        suffix={card.suffix}
                      />
                    </span>
                  </div>
                  <h3 className={`font-display font-bold text-lg ${isDark ? "text-neutral-200" : "text-[#1D1D1F]"}`}>
                    {card.title}
                  </h3>
                </div>

                {/* Card Bottom: Description */}
                <div className={`border-t pt-4 flex justify-between items-center ${isDark ? "border-neutral-800" : "border-gray-100"}`}>
                  <p className={`font-sans text-xs font-medium ${isDark ? "text-neutral-400" : "text-gray-500"}`}>
                    {card.subtitle}
                  </p>
                  <p className="font-mono text-[9px] tracking-wider text-red-500 font-extrabold uppercase">
                    ACTIVE
                  </p>
                </div>
              </div>
            );
          })}
        </div>

        {/* Brand Collaborations, Core Audience & Testimonial Track */}
        <div className="mt-24 pt-16 border-t border-gray-100 grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start">
          {/* Left Column: Core Audience Insights & Testimonial */}
          <div className="lg:col-span-5 space-y-10">
            <div className="space-y-4">
              <span className="font-mono text-xs font-semibold uppercase tracking-widest text-red-600">
                AUDIENCE PROFILE
              </span>
              <h3 className="font-display font-bold text-2xl md:text-3xl text-[#1D1D1F] tracking-tight">
                Subscribers & Core Base
              </h3>
              <p className="font-sans text-sm text-gray-500 leading-relaxed">
                <strong>Subscribers:</strong> 3.28M+ Machans (1M+ primary hub & counting).
              </p>
              <div className="p-6 bg-red-50/50 rounded-2xl border border-red-100/60 space-y-3">
                <p className="font-sans text-xs text-red-800 leading-relaxed">
                  <strong>Core Audience:</strong> Youth, families, and travel enthusiasts across Kerala and the global Malayalam diaspora.
                </p>
                <p className="font-sans text-xs text-red-800 leading-relaxed">
                  <strong>Engagement Rate:</strong> Exceptionally high community interaction via YouTube Community Tab and Instagram Reels.
                </p>
              </div>
            </div>

            {/* Testimonials Quote - What the Machans Say */}
            <div className="space-y-4">
              <span className="font-mono text-xs font-bold text-gray-400 uppercase tracking-widest block">
                💬 WHAT THE "MACHANS" SAY
              </span>
              <div className="bg-[#1D1D1F] text-white p-7 rounded-[28px] border border-neutral-800 shadow-xs relative overflow-hidden group">
                <div className="absolute top-4 right-6 text-6xl font-display text-neutral-800 font-extrabold select-none opacity-50">
                  “
                </div>
                <p className="font-display font-medium text-base md:text-lg leading-relaxed text-neutral-100 mb-4 italic z-10 relative">
                  "Your vlogs feel like hanging out with an elder brother. Never skip a single upload!"
                </p>
                <div className="border-t border-neutral-800 pt-3 flex justify-between items-center font-mono text-[10px] text-neutral-400">
                  <span className="font-sans font-bold text-red-500">
                    — A True Subscriber
                  </span>
                  <span className="uppercase text-[9px] text-neutral-500">
                     Verified Machan
                  </span>
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Brand Collaborations & Media Integrations */}
          <div className="lg:col-span-7 space-y-6">
            <div className="space-y-2">
              <span className="font-mono text-xs font-semibold uppercase tracking-widest text-[#1D1D1F]">
                🤝 SPONSORSHIPS & ADVERTISING
              </span>
              <h3 className="font-display font-bold text-2xl md:text-3xl text-[#1D1D1F] tracking-tight">
                Brand Collaborations & Media
              </h3>
              <p className="font-sans text-xs text-gray-500">
                Partnering with regional and national corporate sectors for native product placement, extreme reviews, and high-engagement activations.
              </p>
            </div>

            {/* Interactive Apple-inspired Grid Table */}
            <div className="border border-gray-100 rounded-3xl overflow-hidden bg-white shadow-3xs">
              <div className="grid grid-cols-3 bg-[#F5F5F7] p-4 font-mono text-[10px] uppercase font-bold text-[#1D1D1F] border-b border-gray-100">
                <div>Brand Sector</div>
                <div>Partnership Type</div>
                <div>Campaign Goal</div>
              </div>

              <div className="divide-y divide-gray-100 font-sans text-xs">
                {/* Row 1 */}
                <div className="grid grid-cols-3 p-4 items-center hover:bg-neutral-50 transition-colors duration-150">
                  <div className="font-bold text-[#1D1D1F]">Automobile</div>
                  <div className="text-gray-600">Vehicle Launches & Roadtrips</div>
                  <div className="text-red-600 font-medium font-mono text-[10px] uppercase tracking-wide">Driving engagement & field awareness</div>
                </div>

                {/* Row 2 */}
                <div className="grid grid-cols-3 p-4 items-center hover:bg-neutral-50 transition-colors duration-150">
                  <div className="font-bold text-[#1D1D1F]">Tech & Gadgets</div>
                  <div className="text-gray-600">Unboxing & Long-term Reviews</div>
                  <div className="text-red-600 font-medium font-mono text-[10px] uppercase tracking-wide">Authentic features showcases</div>
                </div>

                {/* Row 3 */}
                <div className="grid grid-cols-3 p-4 items-center hover:bg-neutral-50 transition-colors duration-150">
                  <div className="font-bold text-[#1D1D1F]">Lifestyle & Apparel</div>
                  <div className="text-gray-600">Brand Ambassador / Merch</div>
                  <div className="text-red-600 font-medium font-mono text-[10px] uppercase tracking-wide">Creating high-converting trendy youth appeal</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
