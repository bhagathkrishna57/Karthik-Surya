/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Youtube, ExternalLink, Award, Radio, Tv, Gamepad2 } from "lucide-react";
import { YOUTUBE_CHANNELS } from "../data";

gsap.registerPlugin(ScrollTrigger);

export default function Channels() {
  const containerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Fade in the section header elements
      gsap.fromTo(
        "#channels-header > *",
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: "#channels-header",
            start: "top 80%",
            toggleActions: "play none none none"
          }
        }
      );

      // Stagger animate channel cards
      if (cardsRef.current) {
        gsap.fromTo(
          cardsRef.current.children,
          { opacity: 0, y: 40, scale: 0.98 },
          {
            opacity: 1,
            y: 0,
            scale: 1,
            duration: 1,
            stagger: 0.15,
            ease: "power4.out",
            scrollTrigger: {
              trigger: cardsRef.current,
              start: "top 75%",
              toggleActions: "play none none none"
            }
          }
        );
      }
    }, containerRef);

    return () => ctx.revert();
  }, []);

  // Icon selector based on channel data
  const getChannelIcon = (channel: typeof YOUTUBE_CHANNELS[0]) => {
    if (channel.logoUrl) {
      return (
        <img
          src={channel.logoUrl}
          alt={channel.name}
          referrerPolicy="no-referrer"
          className="w-full h-full rounded-2xl object-cover"
        />
      );
    }
    switch (channel.id) {
      case "ks-vlogs":
        return (
          <img
            src="https://yt3.googleusercontent.com/ytc/AIdro_lj3jMNN-uLRsEc2ks2NydNf9GMXFeRPUWbz3Dk-uPhuA8=s160-c-k-c0x00ffffff-no-rj"
            alt="Karthik Surya"
            referrerPolicy="no-referrer"
            className="w-full h-full rounded-2xl object-cover"
          />
        );
      case "intelerks":
        return <Radio size={26} className="text-gray-800" />;
      case "pepeepoopoo":
        return <Tv size={26} className="text-amber-500" />;
      case "unleashed":
        return <Gamepad2 size={26} className="text-blue-500" />;
      default:
        return <Youtube size={26} className="text-neutral-500" />;
    }
  };

  return (
    <section
      ref={containerRef}
      id="channels"
      className="bg-white py-24 md:py-36 px-6 md:px-12"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div id="channels-header" className="space-y-4 mb-16 md:mb-24 text-left max-w-2xl">
          <span className="font-mono text-xs font-semibold uppercase tracking-widest text-red-600">
            THE MULTI-CHANNEL NETWORK
          </span>
          <h2 className="font-display font-bold text-4xl md:text-5xl text-[#1D1D1F] tracking-tight">
            The Digital Ecosystem
          </h2>
          <p className="font-sans text-lg text-gray-500">
            Explore the different sides of content across multiple dedicated channels, highlighting lifestyle, structured podcasts, gaming, and pure comedy.
          </p>
        </div>

        {/* Channels Grid - Styled with Apple's clean proportions */}
        <div
          ref={cardsRef}
          id="channels-cards-grid"
          className="grid grid-cols-1 md:grid-cols-2 gap-8"
        >
          {YOUTUBE_CHANNELS.map((channel, idx) => (
            <div
              key={channel.id}
              id={`channel-card-${channel.id}`}
              className="group relative flex flex-col justify-between p-8 bg-[#F5F5F7] rounded-[32px] border border-gray-100 transition-all duration-300 hover:bg-neutral-50 hover:border-gray-200 shadow-xs hover:shadow-md"
            >
              {/* Channel badge and metric header */}
              <div className="flex justify-between items-start mb-6">
                <div className="w-14 h-14 bg-white rounded-2xl flex items-center justify-center shadow-xs border border-gray-100/40 group-hover:scale-105 transition-transform duration-300">
                  {getChannelIcon(channel)}
                </div>
                <div className="text-right">
                  <div className="font-mono text-[9px] text-gray-400 font-bold uppercase tracking-widest">
                    metric status
                  </div>
                  <div
                    className="font-display font-extrabold text-[#1D1D1F] text-xl tracking-tight"
                    style={{ color: channel.id === "ks-vlogs" ? "#DF0000" : "#1D1D1F" }}
                  >
                    {channel.subscribers}
                  </div>
                  <div className="font-sans text-[11px] text-gray-400 font-medium">
                    Verified Subscribers
                  </div>
                </div>
              </div>

              {/* Channel metadata */}
              <div className="space-y-2 mb-8">
                <div className="flex items-center gap-1.5">
                  <span className="font-mono text-[10px] uppercase font-bold tracking-wider px-2 py-0.5 rounded-sm bg-black/5 text-[#1D1D1F]">
                    {channel.tagline}
                  </span>
                </div>
                <h3 className="font-display font-extrabold text-xl md:text-2xl text-[#1D1D1F] group-hover:text-red-600 transition-colors">
                  {channel.name}
                </h3>
                <p className="font-sans text-sm text-gray-500 leading-relaxed max-w-lg">
                  {channel.description}
                </p>
              </div>

              {/* Bottom Subscribe Action Area & Real URL */}
              <div className="pt-4 border-t border-gray-200/40 flex justify-between items-center">
                <span className="text-[11px] text-gray-400 font-mono italic">
                  Surya Net. #{idx + 1}
                </span>

                <a
                  href={channel.youtubeUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  id={`channel-subscribe-link-${channel.id}`}
                  className="inline-flex items-center gap-2 bg-white hover:bg-red-600 hover:text-white text-[#1D1D1F] font-semibold text-xs py-3 px-6 rounded-full border border-gray-200 shadow-2xs group-hover:border-red-500 transition-all duration-300 transform group-hover:translate-x-0.5"
                >
                  Subscribe Channel
                  <ExternalLink size={13} className="opacity-60" />
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
