/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Send, CheckCircle, HelpCircle, Mail, HelpCircle as QuestionIcon, Sparkles } from "lucide-react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "Business Collaboration",
    message: ""
  });

  const [focusedFields, setFocusedFields] = useState<Record<string, boolean>>({});
  const [submitted, setSubmitted] = useState(false);
  const [inboxCount, setInboxCount] = useState(() => {
    const saved = localStorage.getItem("surya_messages");
    if (saved) {
      try {
        return JSON.parse(saved).length;
      } catch (e) {
        return 0;
      }
    }
    return 0;
  });

  const handleFocus = (field: string) => {
    setFocusedFields((prev) => ({ ...prev, [field]: true }));
  };

  const handleBlur = (field: string) => {
    setFocusedFields((prev) => ({ ...prev, [field]: false }));
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.name || !formData.email || !formData.message) {
      alert("Please fill out all required fields.");
      return;
    }

    // Save message locally to make it functional
    const saved = localStorage.getItem("surya_messages");
    const mList = saved ? JSON.parse(saved) : [];
    mList.push({
      ...formData,
      timestamp: new Date().toISOString(),
      id: crypto.randomUUID()
    });
    localStorage.setItem("surya_messages", JSON.stringify(mList));
    setInboxCount(mList.length);

    setSubmitted(true);
    setFormData({ name: "", email: "", subject: "Business Collaboration", message: "" });

    // Reset success animation after a brief duration
    setTimeout(() => {
      setSubmitted(false);
    }, 5000);
  };

  return (
    <section
      id="connect"
      className="bg-white py-24 md:py-36 px-6 md:px-12"
    >
      <div className="max-w-7xl mx-auto">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-20 items-start">
          
          {/* Left Column: Direct Inquiries */}
          <div className="lg:col-span-5 space-y-8">
            <div className="space-y-4">
              <span className="font-mono text-xs font-semibold uppercase tracking-widest text-red-600">
                SECURE COMMUNICATIONS
              </span>
              <h2 className="font-display font-bold text-4xl md:text-5xl text-[#1D1D1F] tracking-tight">
                Let's co-create.
              </h2>
              <p className="font-sans text-lg text-gray-500 leading-relaxed">
                Whether you want to align digital sponsorship campaigns, media invites, or television casting directories, reach out directly.
              </p>
            </div>

            {/* Quick Contact Details */}
            <div className="space-y-4 pt-4">
              <p className="font-mono text-xs font-bold text-gray-400 uppercase tracking-widest">
                DIRECT INBOX CHANNEL
              </p>
              
              <div id="contact-info-card" className="p-6 bg-[#F5F5F7] rounded-3xl border border-neutral-100 flex flex-col gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 bg-white rounded-2xl flex items-center justify-center text-[#1D1D1F] shadow-2xs border border-gray-100/60">
                    <Mail size={20} className="text-red-600" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="font-display font-medium text-[#1D1D1F] text-sm">
                      Karthik Surya Management
                    </h4>
                    <span className="font-sans text-xs text-gray-500 block truncate">
                      business@karthiksurya.com
                    </span>
                  </div>
                </div>

                <div className="border-t border-gray-200/50 pt-4 grid grid-cols-2 gap-4 text-xs font-sans text-gray-500">
                  <div>
                    <span className="font-mono text-[9px] uppercase font-bold text-gray-400 block mb-0.5">Instagram</span>
                    <a href="https://www.instagram.com/karthiksuryavlogs/?hl=en" target="_blank" rel="noopener" className="text-[#1D1D1F] font-bold hover:text-red-600 transition-colors">
                      @karthiksurya
                    </a>
                  </div>
                  <div>
                    <span className="font-mono text-[9px] uppercase font-bold text-gray-400 block mb-0.5">YouTube Hub</span>
                    <a href="https://www.youtube.com/@KarthikSuryavlogs" target="_blank" rel="noopener" className="text-[#1D1D1F] font-bold hover:text-red-600 transition-colors">
                      Karthik Surya Vlogs
                    </a>
                  </div>
                </div>
                
                {inboxCount > 0 && (
                  <div className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-50 border border-emerald-100 rounded-2xl w-fit self-start">
                    <div className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                    <span className="font-mono text-[9px] font-bold text-emerald-600 uppercase">
                      {inboxCount} Message{inboxCount > 1 ? "s" : ""} Saved
                    </span>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: Minimalist borderless animation form */}
          <div className="lg:col-span-7">
            <div className="bg-[#F5F5F7]/30 border border-gray-100 p-8 md:p-12 rounded-[32px]">
              
              {submitted ? (
                <div
                  id="connect-success-panel"
                  className="flex flex-col items-center text-center py-12 space-y-4 animate-scale-up"
                >
                  <div className="w-16 h-16 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-500">
                    <CheckCircle size={44} className="animate-pulse" />
                  </div>
                  <div className="space-y-1.5 text-center">
                    <h3 className="font-display font-extrabold text-2xl text-[#1D1D1F]">
                      Message Received
                    </h3>
                    <p className="font-sans text-sm text-gray-500 max-w-sm mx-auto">
                      Karthik's management team will review your pitch-deck and connect back inside 2 business days.
                    </p>
                  </div>
                  <span className="font-mono text-[9px] text-gray-300 uppercase tracking-widest pt-2">
                    Secured by Surya Net local state
                  </span>
                </div>
              ) : (
                <form
                  id="connect-form"
                  onSubmit={handleSubmit}
                  className="space-y-8"
                >
                  {/* Row 1: Name & Email */}
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-8">
                    {/* Name field */}
                    <div className="relative">
                      <label className="font-mono text-[10px] font-extrabold tracking-widest text-[#1D1D1F] uppercase mb-1 block">
                        Your Name *
                      </label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleChange}
                        onFocus={() => handleFocus("name")}
                        onBlur={() => handleBlur("name")}
                        placeholder="John Doe"
                        required
                        className="w-full bg-transparent border-none py-3 outline-hidden text-base text-[#1D1D1F] placeholder-gray-400 font-sans font-medium"
                      />
                      <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gray-200" />
                      <div
                        className={`absolute bottom-0 left-0 w-full h-[2px] bg-red-600 transition-transform duration-300 origin-left ${
                          focusedFields.name ? "scale-x-100" : "scale-x-0"
                        }`}
                      />
                    </div>

                    {/* Email field */}
                    <div className="relative">
                      <label className="font-mono text-[10px] font-extrabold tracking-widest text-[#1D1D1F] uppercase mb-1 block">
                        Email Address *
                      </label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleChange}
                        onFocus={() => handleFocus("email")}
                        onBlur={() => handleBlur("email")}
                        placeholder="you@domain.com"
                        required
                        className="w-full bg-transparent border-none py-3 outline-hidden text-base text-[#1D1D1F] placeholder-gray-400 font-sans font-medium"
                      />
                      <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gray-200" />
                      <div
                        className={`absolute bottom-0 left-0 w-full h-[2px] bg-red-600 transition-transform duration-300 origin-left ${
                          focusedFields.email ? "scale-x-100" : "scale-x-0"
                        }`}
                      />
                    </div>
                  </div>

                  {/* Row 2: Subject Dropdown (Custom Apple style selector) */}
                  <div className="relative">
                    <label className="font-mono text-[10px] font-extrabold tracking-widest text-[#1D1D1F] uppercase mb-1 block">
                      Inquiry Category
                    </label>
                    <select
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      onFocus={() => handleFocus("subject")}
                      onBlur={() => handleBlur("subject")}
                      className="w-full bg-transparent border-none py-3 outline-hidden text-base text-[#1D1D1F] font-sans font-semibold appearance-none cursor-pointer"
                    >
                      <option value="Business Collaboration">Business Collaboration & Sponsorship</option>
                      <option value="Television Gig">Mainstream Casting / Television Project</option>
                      <option value="Speaking Engagement">Events / Public Presentations</option>
                      <option value="Just Hello">Interactive Creator Greeting</option>
                    </select>
                    <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gray-200" />
                    <div
                      className={`absolute bottom-0 left-0 w-full h-[2px] bg-red-600 transition-transform duration-300 origin-left ${
                        focusedFields.subject ? "scale-x-100" : "scale-x-0"
                      }`}
                    />
                  </div>

                  {/* Row 3: Message Textarea */}
                  <div className="relative">
                    <label className="font-mono text-[10px] font-extrabold tracking-widest text-[#1D1D1F] uppercase mb-1 block">
                      Tell me about your project *
                    </label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      onFocus={() => handleFocus("message")}
                      onBlur={() => handleBlur("message")}
                      placeholder="Share your goals, timeline, and deliverables..."
                      rows={4}
                      required
                      className="w-full bg-transparent border-none py-3 outline-hidden text-base text-[#1D1D1F] placeholder-gray-400 font-sans leading-relaxed font-medium resize-none"
                    />
                    <div className="absolute bottom-0 left-0 w-full h-[1px] bg-gray-200" />
                    <div
                      className={`absolute bottom-0 left-0 w-full h-[2px] bg-red-600 transition-transform duration-300 origin-left ${
                        focusedFields.message ? "scale-x-100" : "scale-x-0"
                      }`}
                    />
                  </div>

                  {/* Submit Trigger with Arrow */}
                  <div className="pt-2 flex justify-between items-center flex-wrap gap-4">
                    <span className="font-mono text-[9px] text-gray-400 font-semibold tracking-wider">
                      * Required field parameters
                    </span>
                    
                    <button
                      type="submit"
                      id="connect-submit-button"
                      className="group inline-flex items-center gap-2 bg-[#1D1D1F] hover:bg-neutral-800 text-white font-bold text-xs uppercase tracking-widest py-4 px-8 rounded-full shadow-md hover:shadow-lg transition-all duration-300 cursor-pointer"
                    >
                      Send Message
                      <Send size={12} className="group-hover:translate-x-0.5 duration-200" />
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
