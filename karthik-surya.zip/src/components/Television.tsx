/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { ScrollTrigger } from "gsap/ScrollTrigger";
import { Tv, Sparkles, CheckCircle2, Award } from "lucide-react";
import { MAINSTREAM_SHOWS } from "../data";

gsap.registerPlugin(ScrollTrigger);

export default function Television() {
  const containerRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Fade in the section header elements
      gsap.fromTo(
        "#tv-header > *",
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 1,
          stagger: 0.15,
          ease: "power3.out",
          scrollTrigger: {
            trigger: "#tv-header",
            start: "top 80%",
            toggleActions: "play none none none"
          }
        }
      );

      // Stagger animate cards
      if (cardsRef.current) {
        gsap.fromTo(
          cardsRef.current.children,
          { opacity: 0, y: 40 },
          {
            opacity: 1,
            y: 0,
            duration: 1.2,
            stagger: 0.2,
            ease: "power3.out",
            scrollTrigger: {
              trigger: cardsRef.current,
              start: "top 75%",
              toggleActions: "play none none none"
            }
          }
        );
      }
    }, containerRef);

    return () => ctx.revert();
  }, []);

  return (
    <section
      ref={containerRef}
      id="television"
      className="bg-[#F5F5F7]/35 py-24 md:py-36 px-6 md:px-12 border-t border-b border-gray-100"
    >
      <div className="max-w-7xl mx-auto">
        {/* Section Header */}
        <div id="tv-header" className="space-y-4 mb-16 md:mb-24 text-left max-w-2xl">
          <span className="font-mono text-xs font-semibold uppercase tracking-widest text-[#1D1D1F]">
            MAINSTREAM ENTERTAINMENT
          </span>
          <h2 className="font-display font-bold text-4xl md:text-5xl text-[#1D1D1F] tracking-tight">
            Television & Shows
          </h2>
          <p className="font-sans text-lg text-gray-500">
            From the phone screen to television primetime, Karthik hosts and judges leading regional entertainment formats with direct, power-packed storytelling.
          </p>
        </div>

        {/* Television Cards Container */}
        <div
          ref={cardsRef}
          id="tv-cards-container"
          className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12"
        >
          {MAINSTREAM_SHOWS.map((show) => (
            <div
              key={show.id}
              id={`tv-card-${show.id}`}
              className="group relative bg-[#F5F5F7] rounded-[32px] p-8 md:p-12 border border-neutral-100 flex flex-col justify-between transition-all duration-300 hover:bg-white hover:border-gray-200/80 shadow-xs hover:shadow-lg"
            >
              {/* Card top branding */}
              <div>
                <div className="flex justify-between items-start mb-8">
                  <div className="p-4 bg-white rounded-2xl text-[#1D1D1F] shadow-xs group-hover:scale-105 transition-transform duration-300">
                    <Tv size={26} className="text-red-600" />
                  </div>
                  <div className="text-right">
                    <span className="inline-flex items-center gap-1 font-mono text-[9px] uppercase font-bold tracking-widest text-red-600 px-2.5 py-1 bg-red-50 border border-red-100/30 rounded-md">
                      <Sparkles size={10} className="fill-current" />
                      Primetime TV
                    </span>
                    <p className="font-display text-sm font-bold text-[#1D1D1F] mt-1.5">
                      {show.channel}
                    </p>
                  </div>
                </div>

                {/* Show main content */}
                <div className="space-y-3 mb-8">
                  <span className="font-mono text-[10px] uppercase font-bold tracking-widest px-2.5 py-1 bg-black/5 text-[#1D1D1F] rounded-md">
                    {show.role}
                  </span>
                  <h3 className="font-display font-extrabold text-2xl md:text-3xl text-[#1D1D1F] leading-tight">
                    {show.title}
                  </h3>
                  <p className="font-sans text-sm text-gray-500 leading-relaxed pt-2">
                    {show.description}
                  </p>
                </div>

                {/* Bullet Points Highlights */}
                <div className="space-y-3 border-t border-gray-200/60 pt-6 mb-8">
                  <p className="font-mono text-[10px] font-bold text-gray-400 uppercase tracking-widest">
                    Milestone Highlights
                  </p>
                  <ul className="space-y-2.5">
                    {show.highlights.map((highlight, index) => (
                      <li key={index} className="flex items-start gap-2.5 text-xs text-gray-600 font-sans">
                        <CheckCircle2 size={15} className="text-emerald-500 shrink-0 mt-0.5" />
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {/* Show card bottom indicator */}
              <div className="flex justify-between items-center text-xs text-gray-400 font-sans pt-4 border-t border-gray-100">
                <span className="font-mono italic text-[10px]">
                  Broadcasting Net: {show.channel}
                </span>
                <div className="flex items-center gap-1.5 font-semibold text-[#1D1D1F]">
                  <Award size={14} className="text-red-500" />
                  Season Gold Status
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
