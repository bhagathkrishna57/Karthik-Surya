/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useRef } from "react";
import { gsap } from "gsap";
import { Youtube, ArrowRight, CornerDownRight, Zap } from "lucide-react";

export default function Hero() {
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLDivElement>(null);
  const placeholderRef = useRef<HTMLDivElement>(null);
  const actionsRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    // Elegant split characters/fade transition for hero text using GSAP
    const ctx = gsap.context(() => {
      // 1. Title fade up & letter spacing compress
      gsap.fromTo(
        titleRef.current,
        { opacity: 0, y: 50, letterSpacing: "-0.08em" },
        { opacity: 1, y: 0, letterSpacing: "-0.04em", duration: 1.2, ease: "power4.out" }
      );

      // 2. Subtitle slide up slightly later
      gsap.fromTo(
        subtitleRef.current,
        { opacity: 0, y: 30 },
        { opacity: 1, y: 0, duration: 1, delay: 0.3, ease: "power3.out" }
      );

      // 3. Actions fade
      gsap.fromTo(
        actionsRef.current,
        { opacity: 0, y: 20 },
        { opacity: 1, y: 0, duration: 1, delay: 0.5, ease: "power3.out" }
      );

      // 4. Placeholder box scale-up with 3D feel
      gsap.fromTo(
        placeholderRef.current,
        { opacity: 0, scale: 0.95, y: 30 },
        { opacity: 1, scale: 1, y: 0, duration: 1.4, delay: 0.2, ease: "power4.out" }
      );
    });

    return () => ctx.revert();
  }, []);

  const handleScrollTo = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      const offset = 80;
      const bodyRect = document.body.getBoundingClientRect().top;
      const elementRect = element.getBoundingClientRect().top;
      const elementPosition = elementRect - bodyRect;
      const offsetPosition = elementPosition - offset;

      window.scrollTo({
        top: offsetPosition,
        behavior: "smooth"
      });
    }
  };

  return (
    <section
      id="home"
      className="relative min-h-[92vh] flex items-center justify-center bg-white px-6 md:px-12 pt-28 pb-10"
    >
      {/* Background visual accents - extremely subtle geometric light patterns */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-[20%] left-[10%] w-[35vw] h-[35vw] rounded-full bg-[#F5F5F7]/40 blur-[120px] mix-blend-multiply" />
        <div className="absolute bottom-[10%] right-[10%] w-[40vw] h-[40vw] rounded-full bg-red-50/30 blur-[140px] mix-blend-multiply" />
      </div>

      <div className="max-w-7xl mx-auto w-full grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-center">
        {/* Left Column - Big Display Typography */}
        <div className="lg:col-span-7 flex flex-col justify-center space-y-8 z-10">
          <div className="inline-flex items-center gap-2 px-3 py-1 bg-red-50 rounded-full border border-red-100/60 w-fit">
            <Zap size={14} className="text-red-600 fill-red-600" />
            <span className="font-mono text-[11px] font-semibold tracking-wider text-red-600 uppercase">
              CONTENT CREATOR | TRAVEL VLOGGER | ENTERTAINER
            </span>
          </div>

          <div className="space-y-4">
            <h1
              ref={titleRef}
              id="hero-massive-headline"
              className="apple-title-massive text-[#1D1D1F] leading-tight"
            >
              Karthik <br />
              <span className="text-[#1D1D1F] relative">
                Surya
                <span className="absolute left-0 bottom-1 md:bottom-2 w-full h-[6px] md:h-[10px] bg-red-600/10 -z-10 rounded-full" />
              </span>
              .
            </h1>

            <p
              ref={subtitleRef}
              id="hero-editorial-subheadline"
              className="apple-body text-gray-700 max-w-xl font-medium text-lg leading-relaxed md:text-xl"
            >
              "Hey Machanmaare! Welcome to my digital space. Capturing life, creating smiles, and exploring the world one vlog at a time."
            </p>
          </div>

          {/* Action item buttons with animation underscores */}
          <div
            ref={actionsRef}
            className="flex flex-wrap items-center gap-6 pt-2"
          >
            <button
              id="hero-watch-btn"
              onClick={() => handleScrollTo("videos")}
              className="group relative inline-flex items-center gap-2 cursor-pointer text-base font-semibold text-[#1D1D1F] py-1"
            >
              Watch Latest Vlogs
              <ArrowRight size={18} className="transition-transform group-hover:translate-x-1 duration-300 text-red-600" />
              <span className="absolute bottom-0 left-0 w-full h-[1.5px] bg-[#1D1D1F] origin-left scale-x-100 group-hover:scale-x-[1.2] transition-transform duration-300" />
            </button>

            <button
              id="hero-touch-btn"
              onClick={() => handleScrollTo("connect")}
              className="group flex items-center gap-1.5 cursor-pointer text-gray-500 hover:text-[#1D1D1F] transition-colors text-base font-medium py-1"
            >
              Get in Touch
              <span className="font-mono text-gray-300 group-hover:text-red-600 font-bold transition-colors ml-0.5">{`>`}</span>
            </button>
          </div>
        </div>

        {/* Right Column - Premium Apple Photo Placeholder (No AI images!) */}
        <div className="lg:col-span-5 flex justify-center lg:justify-end z-10">
          <div
            ref={placeholderRef}
            id="hero-portrait-frame"
            className="group relative w-full max-w-[400px] aspect-[4/5] bg-[#F5F5F7] rounded-[32px] overflow-hidden border border-neutral-100 flex flex-col justify-between p-8 shadow-xs hover:shadow-lg transition-all duration-500 hover:border-gray-200"
          >
            {/* Visual background texture for placeholder */}
            <div className="absolute inset-0 bg-linear-to-b from-[#F2F2F5]/50 to-[#EAEAEF]/80 group-hover:scale-105 transition-transform duration-700 ease-out -z-10" />
            <div className="absolute inset-0 opacity-15 mix-blend-overlay -z-10 bg-[radial-gradient(#1D1D1F_1px,transparent_1px)] [background-size:24px_24px]" />

            {/* Top Indicator */}
            <div className="flex justify-between items-start">
              <span className="font-mono text-[9px] text-gray-400 font-semibold tracking-widest uppercase">
                PORTRAIT AREA
              </span>
              <CornerDownRight size={16} className="text-gray-300 group-hover:text-red-500 transition-colors" />
            </div>

            {/* Center graphical accent */}
            <div id="hero-graphic-core" className="my-auto flex flex-col items-center text-center space-y-4">
              <div className="w-20 h-20 rounded-full bg-white p-1 flex items-center justify-center shadow-md group-hover:scale-110 transition-transform duration-300 border border-gray-100">
                <img
                  src="https://yt3.googleusercontent.com/ytc/AIdro_lj3jMNN-uLRsEc2ks2NydNf9GMXFeRPUWbz3Dk-uPhuA8=s160-c-k-c0x00ffffff-no-rj"
                  alt="Karthik Surya Youtube Channel Avatar"
                  referrerPolicy="no-referrer"
                  className="w-full h-full rounded-full object-cover"
                />
              </div>
              <div className="space-y-1.5">
                <p className="font-display font-bold text-[#1D1D1F] text-base">
                  Karthik Surya
                </p>
                <span className="inline-flex items-center gap-1 font-mono text-[9px] uppercase font-bold tracking-widest text-red-600 px-2 py-0.5 bg-red-50 rounded-sm">
                  ★ PRIMARY HUB
                </span>
                <p className="font-sans text-xs text-gray-400">
                  3.28M+ Creative Powerhouse
                </p>
              </div>
            </div>

            {/* Bottom Info bar */}
            <div className="border-t border-gray-200/60 pt-4 flex justify-between items-center text-left">
              <div>
                <p className="font-mono text-[9px] text-gray-400 font-bold uppercase tracking-widest">
                  aspect ratio
                </p>
                <p className="font-display text-xs font-semibold text-[#1D1D1F]">
                  4:5 Professional Frame
                </p>
              </div>
              <p className="text-[10px] text-gray-400 italic font-mono">
                Surya vlogs
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
